.. ref-contrib

=======
contrib
=======

boto.contrib
------------

.. automodule:: boto.contrib
   :members:   
   :undoc-members:

boto.contrib.m2helpers
----------------------

.. note::

   This module requires installation of M2Crypto__ in your Python path.
   
   __ http://sandbox.rulemaker.net/ngps/m2/

.. automodule:: boto.contrib.m2helpers
   :members:   
   :undoc-members:

boto.contrib.ymlmessage
-----------------------

.. automodule:: boto.contrib.ymlmessage
   :members:   
   :undoc-members: