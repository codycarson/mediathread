.. ref-glacier

=======
Glacier
=======

boto.glacier
------------

.. automodule:: boto.glacier
   :members:
   :undoc-members:

boto.glacier.layer1
-------------------

.. automodule:: boto.glacier.layer1
   :members:
   :undoc-members:

boto.glacier.layer2
-------------------

.. automodule:: boto.glacier.layer2
   :members:
   :undoc-members:

boto.glacier.vault
------------------

.. automodule:: boto.glacier.vault
   :members:
   :undoc-members:

boto.glacier.job
----------------

.. automodule:: boto.glacier.job
   :members:
   :undoc-members:

boto.glacier.writer
-------------------

.. automodule:: boto.glacier.writer
   :members:
   :undoc-members:

boto.glacier.concurrent
-----------------------

.. automodule:: boto.glacier.concurrent
   :members:
   :undoc-members:

boto.glacier.exceptions
-----------------------

.. automodule:: boto.glacier.exceptions
   :members:
   :undoc-members:


