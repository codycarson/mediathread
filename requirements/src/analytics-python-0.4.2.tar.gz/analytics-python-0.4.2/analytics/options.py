
host = 'https://api.segment.io'

endpoints = {
    'track': '/v1/track',
    'identify': '/v1/identify',
    'alias': '/v1/alias',
    'batch': '/v1/import'
}
